/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soccer;

public class Futbolista extends seleccionsoccer{
    int dorsal;
    String demarcacion;
    
public Futbolista(){
   super();
}

    public Futbolista(int dorsal, String demarcacion, int Id, String Apellidos, String Nombre, int Edad) {
        super(Id, Apellidos, Nombre, Edad);
        this.dorsal = dorsal;
        this.demarcacion = demarcacion;
    }
   public int getdorsal(){
        return dorsal;
    }public void set(int dorsal){
        this.dorsal = dorsal;
    } 
    
    
    public String getdemarcacion(){
        return demarcacion;
    }public void set(String demarcacion){
        this.demarcacion = demarcacion;
    } 
    
    public void jugarpartido(){
    }
    public void entrenar(){
    }
    @Override
    public void viajar(){
        System.out.println("el futbolista viaja");
    }
    @Override
    public void concentrarse(){
        System.out.println("el futbolista se concentra");
    }
}
