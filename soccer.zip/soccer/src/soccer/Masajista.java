/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soccer;

/**
 *
 * @author J3 PC12
 */
public class Masajista extends seleccionsoccer{
    String Titulacion;
    int añosExperiencia;
    
    public Masajista(){
        super();
    }

    public Masajista(String Titulacion, int añosExperiencia, int Id, String Apellidos, String Nombre, int Edad) {
        super(Id, Apellidos, Nombre, Edad);
        this.Titulacion = Titulacion;
        this.añosExperiencia = añosExperiencia;
    }
    public String Titulacion(){
        return Titulacion;
    }public void set(String Titulacion){
        this.Titulacion = Titulacion;
        
    }public int añosExperiencia(){
        return añosExperiencia;
    }public void set(int añosExperiencia){
        this.añosExperiencia = añosExperiencia;
    }
    public void dar_Masaje(){
        
    }
    @Override
    public void viajar(){
        System.out.println("el masajista viaja");
    }
    @Override
    public void concentrarse(){
        System.out.println("el masajista se concentra");
    }
}
