/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectocafee;

/**
 *
 * @author J3
 */
public class cafatere {
    
   String marca;
   String color; 

    public cafatere(String marca, String color) {
        this.marca = marca;
        this.color = color;
    }
 public void prepararcafecito(){
     
     System.out.println("1. Se calienta el agua a 50°c");
        System.out.println("2. Mezcla el cafe con el agua");
            System.out.println("3. El cafe esta preparado en la taza");
     
     
     
     
     
}
    
    
    
    
    
    
    
    
    
}
