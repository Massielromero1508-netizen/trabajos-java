/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectocafee;

/**
 *
 * @author J3
 */
public class Proyectocafee {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        cafetera micafetera = new 
    }
    
}
