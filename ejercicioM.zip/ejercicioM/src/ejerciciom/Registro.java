/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciom;

/**
 *
 * @author massiel
 */
public class Registro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mascota mascota1 = new Mascota();
        
        mascota1.setNombre("Scraper");
        mascota1.setEspecie("Perro");
        mascota1.setEdad(13);
        
        System.out.println("Nombre: " + mascota1.getNombre());
        System.out.println("Especie: " + mascota1.getEspecie());
        System.out.println("Edad: " + mascota1.getEdad());
        
        mascota1.setEdad(13);
    }
    
}
