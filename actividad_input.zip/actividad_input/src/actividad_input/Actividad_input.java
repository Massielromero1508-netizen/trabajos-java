/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad_input;
import java.util.Scanner;

public class Actividad_input {
    public static void main(String[] args) {
        
      Scanner input = new Scanner(System.in);
      
      
      System.out.print("Escribe tu nombre");
      String nombre = input.nextLine();
      
      System.out.println("Hola" + nombre);
        
       
        
    }
    
}
