/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad_2;

public class Actividad_2 {

    
    public static void main(String[] args) {
        int operacion = 0;
        int numero_uno = 8;
        int numero_dos = 4;
        int resultado = 0;
        
        
        if (operacion == 1){
            
            resultado = numero_uno + numero_dos;
            System.out.println("El resultado de la suma es:" + resultado) ;
        
        }
        else if(operacion == 2){
            resultado = numero_uno - numero_dos;
            System.out.println("El resultado de la resta es:" + resultado) ;
       
        }
        else if(operacion == 3){
            resultado = numero_uno * numero_dos;
            System.out.println("El resultado de la multiplicacion es:" + resultado) ;
                    
        
        
        }
        else {
            resultado = numero_uno / numero_dos;
            System.out.println("El resultado de la division es:" + resultado) ;
        
        }
    }
    
}
