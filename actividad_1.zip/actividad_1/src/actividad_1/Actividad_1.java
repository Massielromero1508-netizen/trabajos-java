/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad_1;

public class Actividad_1 {

    
    public static void main(String[] args) {
        
        int numero_1 = 20;
        int numero_2 = 10;
        int resultado = 0;
        
     resultado = numero_1 + numero_2;
     
     if (resultado >= 30){
      
         System.out.println("el numero es bajo: y equivale a :" + resultado) ;
     
     }
     else{
         
         System.out.println("el numero es alto: y equivale a :" + resultado) ;
     
     
     }         
        
        
        
    }
    
}
